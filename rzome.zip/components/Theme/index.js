﻿import { createTheme } from "@mui/material/styles";

const Theme = createTheme({
  direction: "rtl",

  typography: {
    allVariants: {
      fontFamily: "IranSanse",
      textTransform: "none",
    },
    h6: {
      fontSize: "1.1rem",
    },
  },

  palette: {
    green: {
      main: "#19b179",
    },
    gray: {
      main: "#DADADA",
    },
    white: {
      main: "#fff",
    },
    divider: "#dadada22",
  },
});

export default Theme;
