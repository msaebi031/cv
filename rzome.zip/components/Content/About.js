﻿import { Button, Grid, Typography } from "@mui/material";
import DownloadRoundedIcon from "@mui/icons-material/DownloadRounded";

const About = () => {
  return (
    <Grid
      container
      sx={{
        paddingTop: 8,
      }}
      id="about"
      data-aos="fade-up"
    >
      <Grid
        md={6}
        item
        sx={{
          display: { xs: "none", md: "block" },
        }}
      >
        <img
          src={"/img/about.png"}
          alt="Image About"
          title="درباره من"
          className="img-about"
        />
      </Grid>
      <Grid xs={12} sm={12} md={6} item>
        <Typography className="color-white" component="h2" variant="h3">
          درباره من
        </Typography>

        <Typography
          component="h6"
          variant="h6"
          className="color-gray-light font-family-light"
          sx={{
            paddingTop: { xs: 3 },
          }}
        >
          بنده محمدمهدی صائبی هستم ، ایده پرداز ، طراح و برنامه نویس وب . 19 سال
          سن دارم و 2 سال هست که بصورت حرفه طراحی وب رو انجام میدم. 1 سال هم هست
          که بصورت خصوصی و تیمی سابقه انجام پروژه های وب و ربات رو دارم.
        </Typography>
        <Button
          color="green"
          endIcon={
            <DownloadRoundedIcon
              sx={{
                paddingRight: 2,
              }}
            />
          }
          variant="contained"
          className="color-gray-light"
          size="large"
          sx={{
            fontSize: 18,
            marginTop: 3,
          }}
          href="artan.pdf"
        >
          دانلود رزومه
        </Button>
      </Grid>
    </Grid>
  );
};

export default About;
