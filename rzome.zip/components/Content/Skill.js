﻿import { Box, Grid, Typography } from "@mui/material";
import { Line } from "rc-progress";

const Skill = () => {
  const items = [
    { text: "JavaScript", number: 70 },
    { text: "TypeScript", number: 70 },
    { text: "React Js", number: 85 },
    { text: "Next Js", number: 80 },
    { text: "Material Ui", number: 90 },
    { text: "Bootstrap", number: 90 },
    { text: "Html & Css", number: 80 },
    { text: "Sass", number: 70 },
    { text: "Redux", number: 70 },
    { text: "Web Pack", number: 75 },
    { text: "Ui", number: 90 },
    { text: "Ux", number: 80 },
  ];

  return (
    <Grid
      container
      spacing={4}
      columnSpacing={{ xs: 0, sm: 2, lg: 4 }}
      data-aos="zoom-in"
    >
      <Grid xs={12} item id="skill">
        <Box textAlign="center" py={2} pt={10}>
          <Typography className="color-white" component="h2" variant="h3">
            مهارت من
          </Typography>
        </Box>
      </Grid>
      {items.map((item, index) => (
        <Grid xs={12} sm={6} item key={index}>
          <Box
            sx={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
            }}
          >
            <Typography
              className="color-white font-family-light"
              component="p"
              variant="p"
            >
              %{item.number}
            </Typography>
            <Typography
              className="color-white font-family-light"
              component="p"
              variant="p"
            >
              {item.text}
            </Typography>
          </Box>
          <Line
            percent={item.number}
            strokeWidth="1"
            strokeColor="#19b179"
            trailColor="#555555"
          />
        </Grid>
      ))}
    </Grid>
  );
};

export default Skill;
