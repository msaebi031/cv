﻿import { Box, Grid, Typography } from "@mui/material";

const Work = () => {
  const workExamples = [
    { text: "تاپ لرن", src: "img/toplearn.png" },
    { text: "تلوبیون", src: "img/telewebion.png" },
    { text: "نیک موزیک", src: "img/nic-music.png" },
    { text: "بازار", src: "img/bazar.png" },
  ];
  return (
    <Grid
      container
      spacing={3}
      columnSpacing={{ xs: 0, sm: 3 }}
      sx={{
        paddingBottom: { sm: 10 },
      }}
      data-aos="fade-down"
    >
      <Grid xs={12} item id="work">
        <Box textAlign="center" py={2} pt={10}>
          <Typography className="color-white" component="h2" variant="h3">
            نمونه کار ها
          </Typography>
          <Typography className="color-green" component="h4" variant="h6">
            تمامی نمونه کار ها بصورت عکس است و در هیچ جایی جز سایت اصلی ران نمی
            باشد!
          </Typography>
        </Box>
      </Grid>

      {workExamples.map((res, index) => (
        <Grid xs={12} sm={6} item key={index} className="relative">
          <img
            src={res.src}
            title={res.text}
            alt="Work Example"
            className="w-100 rounded"
          />
          <div className="hover-img">
            <Box textAlign="center" className="top-50">
              <Typography className="color-white" component="p" variant="h5">
                {res.text}
              </Typography>
            </Box>
          </div>
        </Grid>
      ))}
    </Grid>
  );
};

export default Work;
