﻿import { Container } from "@mui/material";
import About from "./About";
import Skill from "./Skill";
import Work from "./Work";

const Content = () => {
  return (
    <div className="bg-purple">
      <Container maxWidth="xl">
        <About />
        <Skill />
        <Work />
      </Container>
    </div>
  );
};

export default Content;
