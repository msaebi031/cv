﻿import { useState } from "react";
import { Box, Menu, MenuItem, Toolbar, Typography,Link } from "@mui/material";
import MenuIcon from "@mui/icons-material/Menu";
import IconButton from "@mui/material/IconButton";

const NavBar = () => {
  const pages = [
   {text : "درباره من", href : "#about"},
   {text : "مهارت های من", href : "#skill"},
   {text : "نمونه کار ها", href : "#work"},
   {text : "تماس با من", href : "#contact"},
   ];

  const [anchorElNav, setAnchorElNav] = useState(null);

  const handleOpenNavMenu = (event) => {
    setAnchorElNav(event.currentTarget);
  };

  const handleCloseNavMenu = () => {
    setAnchorElNav(null);
  };

  return (
    <Toolbar disableGutters>
      <Box
        sx={{
          flexGrow: 1,
          display: { xs: "flex", md: "none" },
          justifyContent: "space-between",
          alignItems: "center",
          padding: "25px",
        }}
      >
        <div>
          <IconButton
            size="large"
            aria-label="account of current user"
            aria-controls="menu-appbar"
            aria-haspopup="true"
            onClick={handleOpenNavMenu}
            color="gray"
            sx={{
              border: "1px solid #DADADA",
              padding: "8px",
              borderRadius: "15%",
            }}
          >
            <MenuIcon />
          </IconButton>
          <Menu
            id="menu-appbar"
            anchorEl={anchorElNav}
            anchorOrigin={{
              vertical: "bottom",
              horizontal: "left",
            }}
            keepMounted
            transformOrigin={{
              vertical: "top",
              horizontal: "left",
            }}
            open={Boolean(anchorElNav)}
            onClose={handleCloseNavMenu}
            sx={{
              display: { xs: "block", md: "none" },
              marginTop: 1,
            }}
          >
            {pages.map((page, index) => (
              <MenuItem key={index}>
                <Typography
                  className="color-gray-light hover-navbar"
                >
                  {page.text}
                </Typography>
              </MenuItem>
            ))}
          </Menu>
        </div>
        <Typography className="color-gray-light font-size-20">Artan</Typography>
      </Box>
      <Box
        sx={{
          flexGrow: 1,
          display: { xs: "none", md: "flex" },
          justifyContent: "center",
        }}
      >
        {pages.map((page, index) => (
          <MenuItem key={index} >
             <Link href={page.href}>
            <Typography
              sx={{
                my: 2,
                display: "block",
              }}
              className="color-gray-light font-size-20 hover-navbar"
            >
              {page.text}
            </Typography>
          </Link>
          </MenuItem>
        ))}
      </Box>
    </Toolbar>
  );
};

export default NavBar;
