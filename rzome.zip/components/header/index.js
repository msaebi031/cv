﻿import { Container } from "@mui/material";
import Content from "./Content";
import NavBar from "./NavBar";

const Header = () => {
  return (
    <div className="bg">
      <Container maxWidth="xl">
        <NavBar />
        <Content />
      </Container>
    </div>
  );
};

export default Header;
