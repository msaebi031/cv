﻿import { Grid, Typography, Box, Divider, Link, Tooltip } from "@mui/material";
import {
  EmailOutlined,
  CallOutlined,
  AddLocationAltOutlined,
  FacebookOutlined,
  Instagram,
  WhatsApp,
  Telegram,
  GitHub,
} from "@mui/icons-material";

const Content = () => {
  const items = [
    { text: "M.saebi9@gmail.com", icon: <EmailOutlined /> },
    { text: "0990-975-6978", icon: <CallOutlined /> },
    { text: "ایران - تهران", icon: <AddLocationAltOutlined /> },
  ];

  const socailMedia = [
    { icon: <FacebookOutlined />, link: "#", text: "FaceBook" },
    {
      icon: <Instagram />,
      link: "https://instagram.com/m.saebi82",
      text: "Instagram",
    },
    { icon: <WhatsApp />, link: "+989909756978", text: "WhatApp" },
    { icon: <Telegram />, link: "https://t.me/mr_saebi", text: "Telegram" },
    { icon: <GitHub />, link: "#", text: "GitHub" },
  ];

  return (
    <Grid container>
      <Grid xs={12} sm={10} md={7} lg={6} item>
        <Box className="glass_header" mt={10}>
          <Box textAlign="center">
            <Typography
              className="color-white"
              component="h1"
              variant="h3"
              px={3}
              sx={{
                paddingTop: { xs: 4, sm: 5 },
              }}
            >
              محمد مهدی صائبی
            </Typography>
            <Typography
              className="color-gray-light font-family-light"
              component="h2"
              variant="h5"
              py={2}
            >
              طراح و توسعه دهنده وب
            </Typography>
            <Box className="d-inline-block" py={3}>
              {items.map((item, index) => (
                <Box
                  key={index}
                  className="d-flex align-center justify-center"
                  pt={2}
                >
                  <span className="color-green">{item.icon}</span>
                  <Typography
                    className="color-gray-light font-family-light d-inline"
                    component="p"
                    variant="h6"
                    pr={2}
                  >
                    {item.text}
                  </Typography>
                </Box>
              ))}
            </Box>

            <Divider variant="fullWidth" />

            <Box
              className="d-flex align-center justify-center"
              py={1}
              textAlign="center"
            >
              {socailMedia.map((media, index) => (
                <Tooltip title={media.text} key={index}>
                  <Link
                    href={media.link}
                    underline="none"
                    pt={1}
                    className="color-gray-light hover-icon"
                    sx={{
                      paddingLeft: { xs: 1.5, sm: 3 },
                      paddingRight: { xs: 1.5, sm: 3 },
                    }}
                  >
                    {media.icon}
                  </Link>
                </Tooltip>
              ))}
            </Box>
          </Box>
        </Box>
      </Grid>
    </Grid>
  );
};

export default Content;
