﻿import { Container, Grid, Box, Typography } from "@mui/material";
import Call from "./Call";
import Sms from "./Sms";
import { Fragment } from "react";

const Footer = () => {

  return (
    <Fragment>
    <Box className="bg-footer" id="contact">
      <Container maxWidth="lg">
        <Grid container>
          <Grid xs={12} md={6} item>
            <Box textAlign="center" py={6}>
              <Typography
                className="color-white"
                component="h2"
                variant="h3"
                pb={1}
              >
                تماس با من
              </Typography>
            </Box>
            <Grid container className="bg-contect-call" columns={13}>
              <Call />
            </Grid>
          </Grid>

          <Grid xs={12} md={6} item className="bg-contect-sms" my={4}>
            <Box textAlign="center" py={2}>
              <Sms />
            </Box>
          </Grid>

        </Grid>
      </Container>
    </Box>
  <div className="bg-purple">
   <Container maxWidth="lg">
  <Box textAlign="center" py={3}>
  <Typography
                className="color-white font-family-light"
                component="p"
                variant="h6"
              >
                تمامی حقوق های مادی و معنوی مربوط به <span className="color-green">محمد مهدی صائبی</span> محفوظ می باشد.
              </Typography>
                </Box>
                 </Container>
  </div>

    </Fragment>
  );
};

export default Footer;
