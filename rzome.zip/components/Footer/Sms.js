﻿import {
  Typography,
  OutlinedInput,
  TextareaAutosize,
  Button,
  Box,
} from "@mui/material";
import { Fragment,useState } from "react";
import { toast } from 'react-toastify';

const Sms = () => {
  const [disabled,setDisabled] = useState(false);
  const [name,setName] = useState("");
  const [email,setEmail] = useState("");
  const [message,setMessage] = useState("");

  const handleSendMessage = () => {
    setDisabled(true);
    setTimeout(() => {
    setDisabled(false);
  }, 6000);
    if(name && email && message){
    toast.success("با موفقیت ارسال شد!", {
    position: "bottom-right",
  });
  } else {
    toast.error("برای ارسال پیام باید تمامی موارد را پر کنید!", {
    position: "bottom-right",
  });
  }
  }

  return (
    <Fragment>
      <Box my={2}>
        <Typography className="color-white" component="h6" variant="h4">
          ارسال پیام
        </Typography>
      </Box>
      <OutlinedInput
        id="demo-helper-text-misaligned-no-helper"
        placeholder="نام کامل"
        className="input-contect font-family-light"
        color="green"
        onChange={(e) => setName(e.target.value)}
      />
      <OutlinedInput
        id="demo-helper-text-misaligned-no-helper"
        placeholder="ایمیل"
        className="input-contect font-family-light"
        color="green"
        onChange={(e) => setEmail(e.target.value)}
      />
      <TextareaAutosize
        aria-label="minimum height"
        minRows={3}
        placeholder="متن پیام ..."
        className="input-contect font-family-light height-textarea"
        color="green"
        onChange={(e) => setMessage(e.target.value)}
      />

      <Button
        color="green"
        variant="contained"
        className="color-gray-light send-button font-family-light"
        size="large"
        sx={{
          fontSize: 18,
        }}
        onClick={() => handleSendMessage()}
        disabled={disabled}
      >
        ارسال
      </Button>
    </Fragment>
  );
};

export default Sms;
