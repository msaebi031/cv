﻿import { Grid, Box, Typography, Divider } from "@mui/material";
import { Instagram, CallOutlined } from "@mui/icons-material";
import { Fragment } from "react";

const Call = () => {
  return (
    <Fragment>
      <Grid xs={6} item>
        <Box textAlign="center" px={2} py={4}>
          <span className="color-gray-light">
            <CallOutlined className="padding-icon circel" />
          </span>
          <Typography
            className="color-white font-family-light"
            component="h6"
            variant="h5"
            py={2}
          >
            شماره تماس
          </Typography>
          <Typography
            className="color-gray-light font-family-light"
            component="h6"
            variant="h6"
          >
            +98990-975-6978
          </Typography>
        </Box>
      </Grid>
      <Grid
        xs={1}
        item
        sx={{
          display: "flex",
          justifyContent: "center",
        }}
      >
        {/* <Box textAlign="center"> */}
        <Divider
          orientation="vertical"
          flexItem
          sx={{
            height: "100%",
          }}
        />
        {/* </Box> */}
      </Grid>
      <Grid xs={6} item>
        <Box textAlign="center" px={2} py={4}>
          <span className="color-gray-light">
            <Instagram className="padding-icon circel" />
          </span>
          <Typography
            className="color-white font-family-light"
            component="h6"
            variant="h5"
            py={2}
          >
            اینستاگرام
          </Typography>
          <Typography
            className="color-gray-light font-family-light"
            component="h6"
            variant="h6"
          >
            M.saebi82
          </Typography>
        </Box>
      </Grid>
    </Fragment>
  );
};

export default Call;
