import '../public/css/main.css'
import { ThemeProvider } from "@emotion/react";
import Theme from "../components/Theme";

function MyApp({ Component, pageProps }) {
  return (
     <ThemeProvider theme={Theme}>
     <Component {...pageProps} />
     </ThemeProvider>
  )
}

export default MyApp
